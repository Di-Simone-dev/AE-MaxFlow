/*
 * main.cpp
 * --------
 * Traduzione di main.py.
 *
 * Utilizzo (identico al Python):
 *   ./maxflow -pr <dataset|file.max>
 *   ./maxflow -cs <dataset|file.max>
 *   ./maxflow -fullsuite
 *
 * Differenze rispetto al Python:
 *   - La configurazione TOML viene letta da configs/configmain.toml tramite
 *     un parser minimale (nessuna dipendenza esterna: solo std).
 *   - Solo PushRelabel è implementato in questa fase; CapacityScaling e
 *     AlmostLinearTime producono un errore "non ancora portati".
 *   - I Fraction di Python vengono gestiti tramite double + scale_rationals.
 *   - Il formato del CSV è identico al Python (compreso "%.17f" per i tempi).
 */

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <map>
#include <numeric>
#include <regex>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <variant>
#include <vector>

//#include "src/util/parsing.hpp"
//#include "src/push_relabel/push_relabel.hpp"
//#include "src/util/rattoint.hpp"




#include "src/util/parse_dimacs.hpp"
#include "src/util/capacity.hpp"
#include "src/util/fraction.hpp"
#include "src/util/scale_rationals.hpp"

#include "src/almost_linear/almost_linear_time.hpp"
#include "src/capacity_scaling/capacity_scaling.hpp"
#include "src/push_relabel/push_relabel.hpp"

namespace fs = std::filesystem;

// Type aliases
using IntGraph = std::unordered_map<std::pair<int,int>, long long, PairHash>;

// ──────────────────────────────────────────────────────────────────────────────
// Parser TOML minimale (solo sezioni semplici e sezioni annidate con chiavi stringa)
// Sufficiente per configmain.toml, che non usa array né valori numerici TOML.
// ──────────────────────────────────────────────────────────────────────────────

using TomlSection = std::map<std::string, std::string>;
using TomlDoc     = std::map<std::string, TomlSection>;

static std::string trim(const std::string& s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    size_t b = s.find_last_not_of(" \t\r\n");
    return (a == std::string::npos) ? "" : s.substr(a, b - a + 1);
}

static std::string strip_quotes(const std::string& s) {
    if (s.size() >= 2 && s.front() == '"' && s.back() == '"')
        return s.substr(1, s.size() - 2);
    return s;
}

static TomlDoc parse_toml(const std::string& path) {
    std::ifstream f(path);
    if (!f.is_open()) throw std::runtime_error("Impossibile aprire: " + path);

    TomlDoc doc;
    std::string cur_section;

    std::string line;
    while (std::getline(f, line)) {
        std::string l = trim(line);
        if (l.empty() || l[0] == '#') continue;

        if (l[0] == '[') {
            // Sezione: "[algs]" o "[dataset_reali.-BVZ]"
            cur_section = trim(l.substr(1, l.rfind(']') - 1));
            doc[cur_section];  // assicura che la sezione esista
            continue;
        }

        auto eq = l.find('=');
        if (eq == std::string::npos) continue;
        std::string key = trim(l.substr(0, eq));
        std::string val = trim(l.substr(eq + 1));
        key = strip_quotes(key);
        val = strip_quotes(val);

        doc[cur_section][key] = val;
    }
    return doc;
}

// ──────────────────────────────────────────────────────────────────────────────
// Configurazione caricata dal TOML
// ──────────────────────────────────────────────────────────────────────────────

struct Config {
    // [algs]: flag CLI → chiave algoritmo
    std::map<std::string,std::string> algs;

    // [out_files_single]: flag → percorso CSV
    std::map<std::string,std::string> out_files_single;

    // [out_files_bvz] e [out_files_kz2]
    std::map<std::string,std::string> out_files_bvz;
    std::map<std::string,std::string> out_files_kz2;

    // [instances_dir]: chiave algoritmo → directory
    std::map<std::string,std::string> instances_dir;

    // [dataset_reali.*]: flag → {prefix, directory, count, output_dir, out_files_key}
    struct DatasetInfo {
        std::string prefix, directory, output_dir, out_files_key;
        int count;
    };
    std::map<std::string, DatasetInfo> dataset_reali;
};

static Config load_config(const std::string& path) {
    TomlDoc doc = parse_toml(path);
    Config cfg;

    // Sezioni flat
    for (auto& [k, v] : doc["algs"])           cfg.algs[k]            = v;
    for (auto& [k, v] : doc["out_files_single"]) cfg.out_files_single[k] = v;
    for (auto& [k, v] : doc["out_files_bvz"])  cfg.out_files_bvz[k]   = v;
    for (auto& [k, v] : doc["out_files_kz2"])  cfg.out_files_kz2[k]   = v;
    for (auto& [k, v] : doc["instances_dir"])  cfg.instances_dir[k]    = v;

    // Sezioni annidate: "dataset_reali.<flag>"
    for (auto& [sec, kvmap] : doc) {
        if (sec.substr(0, 15) != "dataset_reali.") continue;
        std::string flag = sec.substr(15);
        Config::DatasetInfo di;
        di.prefix       = kvmap.count("prefix")       ? kvmap.at("prefix")       : "";
        di.directory    = kvmap.count("directory")    ? kvmap.at("directory")    : "";
        di.count        = kvmap.count("count")        ? std::stoi(kvmap.at("count")) : 0;
        di.output_dir   = kvmap.count("output_dir")   ? kvmap.at("output_dir")   : "";
        di.out_files_key= kvmap.count("out_files_key")? kvmap.at("out_files_key")  : "";
        cfg.dataset_reali[flag] = di;
    }
    return cfg;
}

// ──────────────────────────────────────────────────────────────────────────────
// Utilità CSV — traduzione diretta delle funzioni Python omonime
// ──────────────────────────────────────────────────────────────────────────────

static void init_csv(const std::string& csv_path,
                     const std::vector<std::string>& header) {
    fs::path p(csv_path);
    if (p.has_parent_path()) fs::create_directories(p.parent_path());

    if (!fs::exists(p)) {
        std::ofstream f(csv_path);
        for (size_t i = 0; i < header.size(); ++i)
            f << (i ? "," : "") << header[i];
        f << "\n";
    }
}

static void scrivi_riga_csv(const std::string& csv_path,
                             const std::vector<std::string>& row) {
    std::ofstream f(csv_path, std::ios::app);
    for (size_t i = 0; i < row.size(); ++i)
        f << (i ? "," : "") << row[i];
    f << "\n";
}

// ──────────────────────────────────────────────────────────────────────────────
// estrai_valore_sol — traduzione di main.py::estrai_valore_sol
// ──────────────────────────────────────────────────────────────────────────────

static long long estrai_valore_sol(const std::string& path) {
    std::ifstream f(path);
    if (!f.is_open()) throw std::runtime_error("File .sol non trovato: " + path);
    std::string line;
    while (std::getline(f, line)) {
        std::istringstream ss(line);
        std::string tag; long long val;
        if (ss >> tag >> val && tag == "s") return val;
    }
    throw std::runtime_error("Nessun flusso trovato nel file: " + path);
}

// ──────────────────────────────────────────────────────────────────────────────
// scala_grafo — traduzione di main.py::scala_grafo_razionale
// Converte capacità double → long long via scale_rationals (se necessario).
// ──────────────────────────────────────────────────────────────────────────────

struct GraphScaled {
    IntGraph graph;
    long long fattore;
};

static GraphScaled scala_grafo(const ParsedGraph& graph_in) {
    // Controlla se ci sono double (capacità non intere)
    bool has_double = false;
    for (auto& [_, cap] : graph_in.graph)
        if (std::holds_alternative<double>(cap)) { has_double = true; break; }

    if (!has_double) {
        // Tutte intere: converti direttamente
        IntGraph ig;
        for (auto& [edge, cap] : graph_in.graph)
            ig[edge] = std::get<long long>(cap);
        return {std::move(ig), 1LL};
    }

    // Estrai i valori come double e scala
    std::vector<std::pair<int,int>> keys;
    std::vector<double> vals;
    keys.reserve(graph_in.graph.size());
    vals.reserve(graph_in.graph.size());
    for (auto& [edge, cap] : graph_in.graph) {
        keys.push_back(edge);
        vals.push_back(std::visit([](auto&& v) -> double {
            using T = std::decay_t<decltype(v)>;
            if constexpr (std::is_same_v<T, Fraction>) return v.to_double();
            else return static_cast<double>(v);
        }, cap));
    }

    auto [scaled, k] = scale_rationals(vals);
    std::cout << "Scaling attivo: k = " << k
              << "  (flusso reale = flusso_intero / " << k << ")\n";

    IntGraph ig;
    for (size_t i = 0; i < keys.size(); ++i)
        ig[keys[i]] = scaled[i];

    return {std::move(ig), k};
}

// ──────────────────────────────────────────────────────────────────────────────
// esegui_max_flow — traduzione di main.py::esegui_max_flow
// Restituisce (flow, elapsed_seconds).
// ──────────────────────────────────────────────────────────────────────────────

static std::pair<long long, double>
esegui_max_flow(const std::string& algorithm, const IntGraph& graph,
                int source, int sink) {
    if (algorithm != "push_relabel") {
        throw std::runtime_error(
            "Algoritmo '" + algorithm + "' non ancora portato in C++. "
            "Solo push_relabel è disponibile in questa fase.");
    }

    PushRelabel solver(graph);

    auto t0 = std::chrono::high_resolution_clock::now();
    long long flow = 0;
    try {
        flow = solver.max_flow(source, sink);
    } catch (const std::out_of_range&) {
        std::cout << "Source isolato → flusso = 0\n";
        flow = 0;
    }
    auto t1 = std::chrono::high_resolution_clock::now();

    double elapsed = std::chrono::duration<double>(t1 - t0).count();
    return {flow, elapsed};
}

// Helper: formatta double con 17 cifre decimali (come f"{elapsed:.17f}" in Python)
static std::string fmt_time(double t) {
    std::ostringstream ss;
    ss << std::fixed << std::setprecision(17) << t;
    return ss.str();
}

// ──────────────────────────────────────────────────────────────────────────────
// run_benchmark_reale — traduzione di main.py::run_benchmark_reale
// ──────────────────────────────────────────────────────────────────────────────

static void run_benchmark_reale(
    const std::string& algorithm,
    const std::string& prefix,
    const std::string& directory,
    int count,
    const std::string& output_dir,
    const std::map<std::string,std::string>& out_files)
{
    // Ricava il nome del file CSV dall'out_files dell'algoritmo
    fs::path csv_path = fs::path(output_dir) /
                        fs::path(out_files.at(algorithm)).filename();

    init_csv(csv_path.string(),
             {"n", "m", "time_seconds", "flow", "graph_file", "correctness"});

    for (int i = 0; i < count; ++i) {
        std::string base       = directory + "/" + prefix + std::to_string(i);
        std::string graph_file = prefix + std::to_string(i);

        ParseResult pg;
        try { pg = parse_dimacs(base + ".max"); }
        catch (const std::exception& e) {
            std::cerr << "Errore: " << e.what() << "\n";
            std::exit(1);
        }

        auto [ig, fattore] = scala_grafo(pg);
        auto [flow, elapsed] = esegui_max_flow(algorithm, ig, pg.source, pg.sink);

        std::string correctness = "N/A";
        std::string sol_path    = base + ".sol";
        if (fs::exists(sol_path)) {
            long long sol = estrai_valore_sol(sol_path);
            correctness   = (sol == flow) ? "RISULTATO CORRETTO" : "NON CORRETTO";
            std::cout << "Atteso: " << sol << "  Ottenuto: " << flow
                      << "  → " << correctness << "\n";
        } else {
            std::cout << "File soluzione non trovato: " << sol_path << "\n";
        }

        scrivi_riga_csv(csv_path.string(), {
            std::to_string(pg.n),
            std::to_string(pg.m_actual),
            fmt_time(elapsed),
            std::to_string(flow),
            graph_file,
            correctness
        });
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// run_benchmark_sintetico — traduzione di main.py::run_benchmark_sintetico
// ──────────────────────────────────────────────────────────────────────────────

static void run_benchmark_sintetico(
    const std::string& algorithm,
    const std::string& instances_dir,
    const std::string& out_dir,
    int runs_per_instance = 7)
{
    std::string csv_path = out_dir + "/" + algorithm + "_results.csv";
    init_csv(csv_path, {"graph_type","cap_type","n","d","seed","m",
                         "median_time","flow","graph_file"});
    std::cout << "Scriverò i risultati in: " << csv_path << "\n";

    // Pattern nomi file: stessi regex del Python
    std::regex pattern_layered(R"(layered_n(\d+)_d(\d+)_seed(\d+)\.max$)");
    std::regex pattern_grid   (R"(grid_n(\d+)_d(\d+)_seed(\d+)\.max$)");

    // 1) Raccolta file
    struct Entry {
        std::string graph_type, cap_type, path, filename;
        int d, n, seed;
    };
    std::vector<Entry> entries;

    for (auto& cap_entry : fs::directory_iterator(instances_dir)) {
        if (!cap_entry.is_directory()) continue;
        std::string cap_type = cap_entry.path().filename().string();

        for (auto& nd_entry : fs::directory_iterator(cap_entry.path())) {
            if (!nd_entry.is_directory()) continue;
            std::string nd_group  = nd_entry.path().filename().string();
            std::string graph_type = (nd_group.rfind("grid", 0) == 0) ? "grid" : "layered";
            const std::regex& pat  = (graph_type == "grid") ? pattern_grid : pattern_layered;

            for (auto& fentry : fs::directory_iterator(nd_entry.path())) {
                if (fentry.path().extension() != ".max") continue;
                std::string filename = fentry.path().filename().string();
                std::smatch m;
                if (!std::regex_search(filename, m, pat)) {
                    std::cout << "Ignoro file non conforme: " << filename << "\n";
                    continue;
                }
                entries.push_back({
                    graph_type, cap_type,
                    fentry.path().string(), filename,
                    std::stoi(m[2]), std::stoi(m[1]), std::stoi(m[3])
                });
            }
        }
    }

    // 2) Ordinamento: graph_type → cap_type → d → n → seed
    std::sort(entries.begin(), entries.end(), [](const Entry& a, const Entry& b) {
        if (a.graph_type != b.graph_type) return a.graph_type < b.graph_type;
        if (a.cap_type   != b.cap_type)   return a.cap_type   < b.cap_type;
        if (a.d != b.d) return a.d < b.d;
        if (a.n != b.n) return a.n < b.n;
        return a.seed < b.seed;
    });

    // 3) Benchmark
    for (auto& e : entries) {
        std::cout << "Processing (type=" << e.graph_type
                  << ", cap=" << e.cap_type
                  << ", d=" << e.d << ", n=" << e.n
                  << ", seed=" << e.seed << "): " << e.path << "\n";

        ParseResult pg;
        try { pg = parse_dimacs(e.path); }
        catch (const std::exception& ex) {
            std::cerr << "Errore nel parsing di " << e.path << ": " << ex.what() << "\n";
            continue;
        }

        auto [ig, fattore] = scala_grafo(pg);
        std::cout << "use_scale = " << (fattore != 1 ? "true" : "false") << "\n";

        std::vector<double> times;
        long long flow_value = 0;

        for (int r = 0; r < runs_per_instance; ++r) {
            auto [flow, elapsed] = esegui_max_flow(algorithm, ig, pg.source, pg.sink);
            if (r == 0) flow_value = flow;
            times.push_back(elapsed);
        }

        // Scarta il primo (warmup) e calcola la mediana del resto
        std::vector<double> rest(times.begin() + 1, times.end());
        std::sort(rest.begin(), rest.end());
        double median_time = rest[rest.size() / 2];
        if (rest.size() % 2 == 0)
            median_time = (rest[rest.size()/2 - 1] + rest[rest.size()/2]) / 2.0;

        std::cout << " → median_time = " << std::fixed << std::setprecision(6)
                  << median_time << "s\n";

        // Flusso reale (come format_flow in Python)
        std::string flow_str;
        if (fattore == 1) {
            flow_str = std::to_string(flow_value);
        } else {
            // Rappresenta come "num/den" (equivalente a Fraction(flow, fattore))
            long long g = std::gcd(flow_value, fattore);
            flow_str    = std::to_string(flow_value / g) + "/" + std::to_string(fattore / g);
        }

        scrivi_riga_csv(csv_path, {
            e.graph_type, e.cap_type,
            std::to_string(e.n), std::to_string(e.d), std::to_string(e.seed),
            std::to_string(pg.m_actual),
            fmt_time(median_time),
            flow_str,
            e.filename
        });
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// run_esperimento_singolo — traduzione di main.py::run_esperimento_singolo
// ──────────────────────────────────────────────────────────────────────────────

static void run_esperimento_singolo(
    const std::string& algorithm,
    const std::string& graph_file,
    const std::string& csv_file)
{
    init_csv(csv_file, {"n","m","time_seconds","flow","graph_file"});

    ParseResult pg;
    try { pg = parse_dimacs(graph_file); }
    catch (const std::exception& e) {
        std::cerr << "Errore: " << e.what() << "\n";
        std::exit(1);
    }

    auto [ig, fattore] = scala_grafo(pg);

    std::cout << "File   : " << graph_file   << "\n";
    std::cout << "Source : " << pg.source << "   Sink : " << pg.sink << "\n";
    std::cout << "Archi  : " << pg.graph.size() << "\n\n";

    auto [flow, elapsed] = esegui_max_flow(algorithm, ig, pg.source, pg.sink);

    std::string flow_str;
    if (fattore == 1) {
        flow_str = std::to_string(flow);
    } else {
        long long g = std::gcd(flow, fattore);
        flow_str    = std::to_string(flow / g) + "/" + std::to_string(fattore / g);
    }

    std::cout << "flow = " << flow << "\n";
    scrivi_riga_csv(csv_file, {
        std::to_string(pg.n), std::to_string(pg.m_actual),
        fmt_time(elapsed), flow_str, graph_file
    });

    std::cout << "Flow = " << flow
              << "  (reale = " << std::fixed << std::setprecision(6)
              << (static_cast<double>(flow) / static_cast<double>(fattore)) << ")\n";
    std::cout << "Tempo = " << std::fixed << std::setprecision(6) << elapsed << " s\n";
}

// ──────────────────────────────────────────────────────────────────────────────
// main — traduzione di main.py __main__
// ──────────────────────────────────────────────────────────────────────────────

int main(int argc, char* argv[]) {
    // Trova la directory dell'eseguibile per risolvere il percorso del config
    fs::path exe_dir = fs::path(argv[0]).parent_path();
    fs::path cfg_path = exe_dir / "configs" / "configmain.toml";

    Config cfg;
    try {
        cfg = load_config(cfg_path.string());
    } catch (const std::exception& e) {
        std::cerr << "Errore nel caricamento della configurazione: " << e.what() << "\n";
        std::cerr << "(percorso cercato: " << cfg_path << ")\n";
        return 1;
    }

    if (argc == 1) {
        std::cerr << "Utilizzo: " << argv[0] << " <flag> [dataset|file]\n";
        return 1;
    }

    std::string alg_flag = argv[1];

    // ── -fullsuite ─────────────────────────────────────────────────────────
    if (alg_flag == "-fullsuite") {
        for (auto& [alg_name, inst_dir] : cfg.instances_dir) {
            run_benchmark_sintetico(alg_name, inst_dir, "benchmarksintetici");
        }
        return 0;
    }

    if (cfg.algs.find(alg_flag) == cfg.algs.end()) {
        std::cerr << "Argomento sconosciuto: " << alg_flag << ". Usa uno tra:";
        for (auto& [k, _] : cfg.algs) std::cerr << " " << k;
        std::cerr << "\n";
        return 1;
    }

    if (argc < 3) {
        std::cerr << "Utilizzo: " << argv[0] << " <flag> <dataset|file>\n";
        return 1;
    }

    std::string algorithm = cfg.algs.at(alg_flag);
    std::string dataset   = argv[2];

    // ── Dataset reali ──────────────────────────────────────────────────────
    if (cfg.dataset_reali.count(dataset)) {
        auto& di = cfg.dataset_reali.at(dataset);
        const auto& out_files = (di.out_files_key == "out_files_bvz")
                                ? cfg.out_files_bvz
                                : cfg.out_files_kz2;
        run_benchmark_reale(algorithm, di.prefix, di.directory,
                            di.count, di.output_dir, out_files);
    }
    // ── Benchmark sintetico ────────────────────────────────────────────────
    else if (dataset == "-SINTH") {
        if (cfg.instances_dir.find(algorithm) == cfg.instances_dir.end()) {
            std::cerr << "Nessuna directory di istanze configurata per: " << algorithm << "\n";
            return 1;
        }
        run_benchmark_sintetico(algorithm, cfg.instances_dir.at(algorithm),
                                "benchmarksintetici");
    }
    // ── Singolo file .max ──────────────────────────────────────────────────
    else {
        if (cfg.out_files_single.find(alg_flag) == cfg.out_files_single.end()) {
            std::cerr << "Nessun file CSV configurato per: " << alg_flag << "\n";
            return 1;
        }
        std::string csv_file = cfg.out_files_single.at(alg_flag);
        std::cout << "graph file = " << dataset << "\n";
        run_esperimento_singolo(algorithm, dataset, csv_file);
    }

    return 0;
}